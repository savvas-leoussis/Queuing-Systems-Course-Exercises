% M/M/2/8 QUEUE WITH THRESHOLD SIMULATION

clc;
clear all;
close all;

mu = 8;
p = [0.5 0.2 0.7];
fig=0;
for p = [0.5 0.2 0.7] 
  fprintf ('p = ');
  fprintf(num2str(p));
  fprintf('\n');
  for lambda=6:1:8
    min_k = 99999;
    for k = 3:1:6
      arrivals = zeros(9+k,1);
      for n=1:1:(9+k)
        arrivals(n) = 0;
      endfor
      total_arrivals = 0;
      current_state = 0;
      previous_mean_clients = 0;
      index = 0;
      clear P;
      threshold = lambda/(lambda + mu); % the threshold used to calculate probabilities
      rand("seed",1);
      transitions = 0; % holds the transitions of the simulation in transitions steps

      while transitions >= 0
        transitions = transitions + 1; % one more transitions step
        
        if mod(transitions,1000) == 0 % check for convergence every 1000 transitions steps
          index = index + 1;
          for i=1:1:length(arrivals)
              P(i) = arrivals(i)/total_arrivals; % calculate the probability of every state in the system
          endfor
          P_blocking = P(length(arrivals));
          mean_clients = 0;
          for i=1:1:length(arrivals)
             if i<=9
                mean_clients = mean_clients + (i-1).*P(i);
             else
                mean_clients = mean_clients + (i-9)*P(i);
             endif
          endfor
          to_plot(index) = mean_clients;  
          if abs(mean_clients - previous_mean_clients) < 0.0000001 % convergence test
            break;
          endif
          
          previous_mean_clients = mean_clients;
          
        endif
        
        random_number = rand(1); % generate a random number (Uniform distribution)
        if current_state == 0 || random_number < threshold % arrival
          total_arrivals = total_arrivals + 1;
          if current_state < k-1
              arrivals(current_state + 1) = arrivals(current_state + 1) + 1;
              current_state = current_state + 1;
          elseif current_state == k-1
              rand_p = rand(1);
              if rand_p<p
                arrivals(current_state + 1) = arrivals(current_state + 1) + 1;
                current_state = current_state + 1;
              else
                arrivals(current_state + 9) = arrivals(current_state + 9) + 1;
                current_state = current_state + 9;
              endif
          elseif (current_state >= k && current_state <= 7)
            arrivals(current_state + 1) = arrivals(current_state + 1) + 1;
            current_state = current_state + 1;
          elseif (current_state > 8 && current_state < 9+k)
            arrivals(current_state + 1) = arrivals(current_state + 1) + 1;
            current_state = current_state + 1;
          endif
        else % departure
          if current_state != 0 % no departure from an empty system
            if (current_state <= k || (current_state >= 5 && current_state <= 8))
                current_state = current_state - 1;
            elseif current_state == k+1
                rand_p = rand(1);
                if rand_p<p
                  current_state = current_state - 1;
                else
                  current_state = current_state + 7;
                endif
            elseif current_state > 8
              current_state = current_state - 9;
            endif
          endif
        endif
      endwhile
      p_not_working_a= P(1)+P(10);
      p_not_working_b=0;
      for i=1:1:k+1
        p_not_working_b = p_not_working_b + P(i);
      endfor
      if (mu*(1-p_not_working_a))/(mu*(1-p_not_working_b)) > 5
          if k < min_k
            min_k = k;
          endif
      endif
      display(lambda);
      display(k);
      display(mean_clients);
      display(" ");
      figure(++fig);
      plot(to_plot);
      title(['k = ' num2str(k) ', lambda = ' num2str(lambda)]);
      ylabel("Mean Clients every 1000 transitions");
    endfor
    if (min_k!=99999)
       fprintf('Best k for lambda=');
       fprintf(num2str(lambda));
       fprintf(': ');
       fprintf(num2str(min_k));
       fprintf('\n');
    else
       fprintf('No Best k found for lambda=');
       fprintf(num2str(lambda));
       fprintf('\n');
    endif
    display("--------------------");
  endfor
  display("~~~~~~~~~~~~~~~~~~~~");
endfor